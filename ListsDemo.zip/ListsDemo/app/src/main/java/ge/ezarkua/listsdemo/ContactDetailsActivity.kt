package ge.ezarkua.listsdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ContactDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_details)
    }
}