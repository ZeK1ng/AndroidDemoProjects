package ge.ezarkua.listsdemo

data class ContactItem(var name: String, var phoneNumber: String)