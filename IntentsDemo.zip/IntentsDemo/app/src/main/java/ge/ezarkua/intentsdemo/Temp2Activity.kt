package ge.ezarkua.intentsdemo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class Temp2Activity : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_temp2)
    }
}