package ge.ezarkua.intentsdemo

//{"answer":"yes","forced":false,"image":"https://yesno.wtf/assets/yes/2-5df1b403f2654fa77559af1bf2332d7a.gif"}
data class AnswerModel(val answer: String, val forced: Boolean, val image: String)